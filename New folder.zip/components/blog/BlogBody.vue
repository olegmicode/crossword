<template lang="pug">

  v-main
    search-container(:config="config.search")
    .container
      h1.text-h4.font-weight-light.my-8 {{ config.blog.header }}
      div(v-for="(item) in getMarkUpParagraphs(config.blog.text)")
        h2.text-h5.font-weight-light.mb-2(v-if="item.style === 'subHeading'") {{ item.text }}
        p.mb-4(v-else) {{ item.text }}
    route-teasers(v-if="config.teaseRoutes" :config="config.teaseRoutes")
    vehicle-teasers(v-if="config.teaseVehicles" :config="config.teaseVehicles")
    read-more(v-if="config.readyForMore" :config="config.readyForMore")
</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";
import markUpMixin from "../../mixins/xnet/markUpMixin";

export default {
  name: 'BlogBody',
  mixins: [configMixin, markUpMixin],

  data() {
    return {}
  },

}
</script>
