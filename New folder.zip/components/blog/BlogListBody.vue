<template lang="pug">

  v-main
    search-container(:config="config.search")
    intro-prominent(:config="config.intro")
    .container
      x-list(:items="config.listBlogs.items"
        :inheritOptions="listOptions" v-slot="slotProps")
        blog-teaser(:config="slotProps.config")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'BlogListBody',
  mixins: [configMixin],

  data() {
    return {
      listOptions: {
        columns: { cols:12, md:6, lg:4, xl:3 }
      }
    }
  },
}
</script>
