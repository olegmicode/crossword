<template lang="pug">

  .container
    intro-teaser(:config="config.heading")
    x-carousel(:items="config.items"
      :inheritOptions="options" v-slot="slotProps")
      blog-teaser(:config="slotProps.config")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'BlogTeasers',
  mixins: [configMixin],
  data() {
    return {
      options: {
        root: {height: 450},
        row: {dense: true},
        columns: {cols: 12, md: 6, lg: 4, xl: 3}
      },
    }
  },

}
</script>
