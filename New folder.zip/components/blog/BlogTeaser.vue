<template lang="pug">
  v-hover(v-if="config.teaserImage" v-slot="{ hover }")
    v-card(height="400px" :elevation="hover ? 16 : 2"  :class="{ 'on-hover': hover }" :to="config.route")
      div(class="fill-height" align="center" justify="center")
        v-img(:src="config.teaserImage.url" height="150px")
        v-card-title.font-weight-light.justify-center()
          h3 {{ config.title }}
        v-card-subtitle.pt-2.grey--text() {{ config.publishedAt.text }}
        v-card-text() {{ config.text }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'BlogTeaser',
  mixins: [configMixin],

}
</script>

<style scoped>
.v-card__text, .v-card__title {
  word-break: normal; /* maybe !important  */
}
</style>