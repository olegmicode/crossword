<template lang="pug">

  v-card()
    div(class="d-flex flex-column flex-sm-row")
      v-avatar(class="ma-3 mx-auto" tile :size="300")
        // carousel
        v-carousel(height="300px" width="300px" v-bind="carouselOptions")
          v-carousel-item(v-for="(image, i) in config.images" :key="i")
            v-img(:src="image.url" width="300" height="300" contain)
      div(class="flex")
        // title area
        div(class="d-flex justify-space-between")
          v-card-title(class="font-weight-light text-h5") {{ config.text }}
          v-card-title(class="font-weight-light text-h5") {{ trans('capacityPax', { pax: config.seatCapacity.text }) }}
        v-divider
        v-row
          // capacity
          v-col(cols="12" sm="6")
            v-row()
              v-col(cols="12")
                v-card-subtitle(class="pt-2 pb-0") {{ trans('capacities') }}:
            v-row(v-for="(prop, p) in capacities" :key="p" class="my-0")
              v-col(cols="8" class="py-0")
                v-card-text(class="pt-1 pb-0") {{ prop.label }}
              v-col(cols="4" class="py-0")
                v-card-text(class="pt-1 pb-0") {{ prop.text }}
          // style
          v-col(cols="12" sm="6")
            v-card-subtitle(class="pt-2 pb-0") {{ trans('style') }}:
            v-card-text(class="pt-1 pb-0") {{ config.style.text }}
            v-card-text(v-for="(prop, p) in styles" :key="p" class="py-1") {{ prop }}
        // amenities
        v-row(v-if="isSleeper" class="mb-4")
          v-col(cols="12" class="py-0")
            v-card-subtitle(class="pt-2 pb-0") {{ trans('amenities') }}:
          // key amenities
          v-col(cols="12" sm="6" class="py-0")
            v-row(v-for="(prop, p) in keyAmenities" :key="p" class="my-0")
              v-col(cols="8" class="py-0")
                v-card-text(class="pt-1 pb-0") {{ prop.label }}
              v-col(cols="4" class="py-0")
                v-icon(class="ml-3 mt-1 mb-0" small :color="prop.has ? 'primary' : 'secondary'") {{ prop.has ? svgCheck : svgClose }}
          // other amenities
          v-col(cols="12" sm="6" class="py-0")
            v-card-text(v-for="(prop, p) in otherAmenities" :key="p" class="pt-1 pb-0") {{ prop }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";
import { mdiClose, mdiCheck } from '@mdi/js'

export default {

  name: 'VehicleItem',
  mixins: [configMixin],
  props: {},
  data() {
    return {
      carouselOptions: {
        continuous: true,
        light: true,
        hideDelimiterBackground: true,
        showArrowsOnHover: true,
        cycle: false,
        interval: 6000
      },
      rules: {
        styles: ['edition', 'transmission'],
        keyAmenities: ['kitchen', 'shower', 'toilet'],
        otherAmenities: ['living', 'climate', 'vehicle'],
        capacities: ['seatCapacity', 'sleepingCapacity', 'beds'],
        excludeSleeper: ['bike', 'car'],
      },
      isSleeper: false,
      capacities: [],
      styles: [],
      keyAmenities: [],
      otherAmenities: [],
      svgClose: mdiClose,
      svgCheck: mdiCheck
    }
  },
  mounted() {
    // sleeper category
    if (this.rules.excludeSleeper.indexOf(this.config.style.category.slug) < 0)
      this.isSleeper = true

    // capacities, amenities
    this.setCapacities()
    this.setKeyAmenities()
    this.setProperties()
  },
  computed: {},
  methods: {
    setCapacities() {
      const result = []
      this.rules.capacities.forEach(key => {
        if (!this.config[key]) return
        result.push({label: this.trans(key), text: this.config[key].text})
      })
      this.capacities = result
    },
    setKeyAmenities() {

      const amenities = this.getKeyAmenities()

      // map to key amenities
      this.keyAmenities = []
      this.rules.keyAmenities.forEach(key =>
          this.keyAmenities.push({
            label: this.trans(key),
            has: amenities.indexOf(key) >= 0
          })
      )
    },
    getKeyAmenities() {

      const result = []

      if (!this.config.properties)
        return result

      // get amenities
      this.config.properties.forEach(item => {
        if (this.rules.keyAmenities.indexOf(item.slug) < 0)
          return
        result.push(item.slug)
      })

        return result
    },

    setProperties() {

      const result = {}
      const self = this

      if (!this.config.properties)
        return

      // prepare
      this.config.properties.forEach(item => {

        // is key amenity
        if (this.rules.keyAmenities.indexOf(item.slug) >= 0)
          return

        // is other property
        if (result[item.type.slug] === undefined)
          result[item.type.slug] = []
        result[item.type.slug].push(item.text)
      })

      // map properties
      this.styles = []
      this.otherAmenities = []
      Object.keys(result).forEach(key => {
        let text = result[key].join(', ')
        if (self.rules.styles.indexOf(key) >= 0)
          self.styles.push(text)
        if (self.rules.otherAmenities.indexOf(key) >= 0)
          self.otherAmenities.push(text)
      })
    }
  }
}
</script>

<style scoped>
.v-card__text, .v-card__title {
  word-break: normal; /* maybe !important  */
}
</style>