<template lang="pug">

  v-card(height="280px")
    div(class="fill-height" align="center" justify="center")
      v-img(:src="config.image.url" contain height="210px" )
      v-divider
      v-card-subtitle {{ config.text }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'VehicleTeaser',
  mixins: [configMixin],

}
</script>
