<template lang="pug">

  v-main
    search-container(:config="config.search")
    intro-prominent(:config="config.intro")
    .container
      x-list(:items="config.listVehicles.items" v-slot="slotProps")
        vehicle-item(:config="slotProps.config" :translations="config.listVehicles.translations")
    read-more(v-if="config.readyForMore" :config="config.readyForMore")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'VehicleListBody',
  mixins: [configMixin],

  data() {
    return {}
  },
}
</script>
