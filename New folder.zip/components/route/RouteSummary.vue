<template lang="pug">

  .container
    v-row
      v-col(:cols="12" md=8 lg=9)
        v-card(:height="height")
          route-map(:config="config.map" type="detail" :height="height")
      v-col(:cols="12" md=4 lg=3)
        v-card(:minHeight="minHeight")
          div(class="flex")
            v-card-title.font-weight-light.text-h5 {{ trans('summary') }}
            v-divider
            v-row
              v-col(cols="6" md=12)
                v-card-subtitle.pb-1.text-capitalize {{ trans('pickUpCity') }}:
                v-card-text {{ config.pickUpCity.text }}
              v-col(cols="6" md=12)
                v-card-subtitle.pb-1.text-capitalize {{ trans('dropOffCity') }}:
                v-card-text {{ config.dropOffCity.text }}
            v-row
              v-col(cols="6" md=12)
                v-card-subtitle.pb-1.text-capitalize {{ trans('travelDaysLabel') }}:
                v-card-text {{ trans('travelDaysText', { days: config.days }) }}
              v-col(cols="6" md=12 v-if="config.distance")
                v-card-subtitle.pb-1.text-capitalize {{ trans('distance') }}:
                v-card-text {{ config.distance.text }}
            v-card-subtitle.pb-1.text-capitalize(v-if="config.vehicleRestriction") {{ trans('restrictions') }}:
            v-card-text(v-if="config.vehicleRestriction") {{ config.vehicleRestriction.text }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'RouteSummary',
  mixins: [configMixin],
  props: {},
  data() {
    return {
      elements: ['title', 'subtitle', 'text'],
      heights: {xs: 400, md: 600}
    }
  },
  computed: {
    height() {
      return this.$getBreakpointValue(this.$vuetify.breakpoint, this.heights, 400)
    },
    minHeight() {
      return this.$vuetify.breakpoint.smAndDown ? 0 : this.height
    }
  },
}
</script>

<style scoped>
/*.vue-map-container {*/
/*  min-height: 500px;*/
/*}*/
</style>
