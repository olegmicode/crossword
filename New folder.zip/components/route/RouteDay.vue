<template lang="pug">

  v-card
    div(class="d-sm-flex d-none")
      include RouteDayDay
      div(class="flex")
        include RouteDayTitel
        v-divider
        include RouteDayText
    div(class="d-sm-none d-flex flex-column")
      div(class="d-flex")
        include RouteDayDay
        include RouteDayTitel
      v-divider
      include RouteDayText

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'RouteDay',
  mixins: [configMixin],
  props: {},
  data() {
    return {}
  },
}
</script>

<style scoped>
.v-card__text, .v-card__title {
  word-break: normal; /* maybe !important  */
}
</style>