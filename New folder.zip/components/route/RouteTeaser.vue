<template lang="pug">

  v-hover(v-slot="{ hover }")
    v-card(:elevation="hover ? 16 : 2"  :class="{ 'on-hover': hover }" :to="config.route")
      div(class="d-flex align-center")
        v-avatar(class="ma-3" tile :size="80")
          v-icon(size="60" color="secondary") {{ svgRoutes }}
        div(class="d-flex flex-grow-1 justify-space-between flex-sm-row flex-column align-sm-center")
          div(class="ma-3 font-weight-light text-sm-h5 text-h6") {{ config.title }}
          div(class="ma-3 font-weight-light text-sm-h5 text-h6 text-right text-no-wrap") {{ trans('travelDays', { days: config.days }) }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";
import {mdiRoutes} from "@mdi/js";

export default {

  name: 'RouteTeaser',
  mixins: [configMixin],
  data() {
    return {
      svgRoutes: mdiRoutes,
    }
  },
}
</script>

<style scoped>
.v-card__title {
  word-break: normal;
}
</style>