<template lang="pug">

  v-main
    search-container(:config="config.search")
    intro-prominent(:config="config.intro")
    route-summary(:config="config.route")
    .container
      x-list(:items="config.route.items" v-slot="slotProps")
        route-day(:config="slotProps.config" :translations="config.route.translations")
    route-teasers(v-if="config.teaseRoutes" :config="config.teaseRoutes")
    vehicle-teasers(v-if="config.teaseVehicles" :config="config.teaseVehicles")
    read-more(v-if="config.readyForMore" :config="config.readyForMore")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'RouteBody',
  mixins: [configMixin],

  data() {
    return {}
  },
}
</script>
