<template lang="pug">

  GmapMap(:zoom="10" :center="center" :options="options" :style="style")
    bmr-map-directions(
      travelMode="DRIVING"
      :origin="origin"
      :destination="destination"
      :waypoints="waypoints"
      :optimizeWaypoints="true"
      :version="version")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'RouteMap',
  mixins: [configMixin],
  props: {
    type: {
      type: String,
      default: 'teaser'
    },
    height: {
      required: true,
      type: Number,
      default: 300
    },
  },

  computed: {
    style() {
      return 'height: :px; width: 100%'.replace(':px', this.height + 'px')
    }
  },
  data() {
    return {
      origin: {},
      destination: {},
      center: {},
      waypoints: [],
      version: 0,
      options: {
        disableDefaultUI: this.type === 'teaser'
      },
    }
  },

  mounted() {
    this.setGoogleLocations()
  },

  methods: {

    setGoogleLocations() {

      setTimeout(() => {
        this.version++
      }, 300);

      this.origin = this.getGooglePlace(this.config.start)
      this.destination = this.getGooglePlace(this.config.target)
      this.center = this.getCenterCoords(this.config.start, this.config.target)
      this.waypoints = this.getGoogleWaypoints(this.config.waypoints)
    },

    getCenterCoords(location1, location2) {

      let coords1 = this.getLocationCoords(location1)
      let coords2 = this.getLocationCoords(location2)
      if (!coords1 || !coords2)
        return null

      return {
        lat: (coords1.lat + coords2.lat) / 2,
        lng: (coords1.lng + coords2.lng) / 2
      }
    },
    getGooglePlace(location) {
      if (!location)
        return null
      if (location.googlePlace)
        return {placeId: location.googlePlace}
      else
        return this.getLocationCoords(location)
    },
    getGoogleWaypoints(locations) {

      let result = []

      if (!locations || !Array.isArray(locations))
        return result

      let waypoint = null
      locations.forEach(item => {
        if ((waypoint = this.getGoogleWaypoint(item)))
          result.push(waypoint)
      })

      return result
    },
    getGoogleWaypoint(location) {

      let result = {
        location: this.getGooglePlace(location),
        // stopover: true
        stopover: (this.type === 'detail')
      }

      if (!result.location)
        return null

      return result
    },
    getLocationCoords(location) {

      if (!location.coordinates)
        return null

      let coords = location.coordinates.split(',')
      if (coords.length < 2)
        return null

      return {
        lat: parseFloat(coords[0]),
        lng: parseFloat(coords[1])
      }
    },
  }
}
</script>

