<template lang="pug">

  v-hover(v-slot="{ hover }")
    v-card(:elevation="hover ? 16 : 2"  :class="{ 'on-hover': hover }"  :to="config.route")
      div(class="d-flex flex-sm-row flex-column-reverse")
        v-avatar(class="ma-3" tile :size="300")
          route-map(:config="config.map" type="teaser" :height="300")
        div(class="flex")
          div(class="d-flex justify-space-between")
            v-card-title {{ config.text }}
            v-card-title {{ trans('travelDays', { days: config.days }) }}
          v-divider
          v-row
            v-col(cols=12 sm=6)
              v-card-subtitle(class="pb-1") {{ trans('route' + (isOneWay ? 'OneWay' : 'RoundTrip')) }}:
              v-card-text {{ routeText }}
              v-card-subtitle(class="pb-1" v-if="config.distance") {{ trans('distance') }}:
              v-card-text(v-if="config.distance") {{ config.distance.text }}
              v-card-subtitle(class="pb-1" v-if="config.vehicleRestriction") {{ trans('restrictions') }}:
              v-card-text(v-if="config.vehicleRestriction") {{ config.vehicleRestriction.text }}
            v-col(cols=12 sm=6)
              v-card-subtitle(class="pb-1") {{ trans('highlights') }}:
              v-card-text {{ highlights }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'RouteItem',
  mixins: [configMixin],
  props: {},
  data() {
    return {}
  },
  computed: {
    isOneWay() {
      return this.config.pickUpCity.slug !== this.config.dropOffCity.slug
    },
    routeText() {
      return this.isOneWay
          ? this.config.pickUpCity.text + ' / ' + this.config.dropOffCity.text
          : this.config.pickUpCity.text
    },
    highlights() {
      return this.config.highlights ? this.config.highlights.join(', ') : ''
    }

  },
}
</script>

<style scoped>
.v-card__title {
  font-size: 21px;
  font-weight: 300;

}
.v-card__text, .v-card__title {
  word-break: normal; /* maybe !important  */
}
</style>