<template lang="pug">

  .container
    intro-teaser(:config="config.heading")
    x-list(:items="config.items" :inheritOptions="options" v-slot="slotProps")
      route-teaser(:config="slotProps.config" :translations="config.translations")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'RouteTeasers',
  mixins: [configMixin],
  data() {
    return {
      options: {},
    }
  },

}
</script>
