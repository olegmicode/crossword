<template lang="pug">

  v-container.backdrop(fluid)
    .container
      .my-8.text-h4.font-weight-light {{ config.header }}
      v-row
        v-col(:cols="12" :md="4" v-for="(icon, key) in propositions" :key="key")
          v-card(flat class="text-center transparent")
            v-icon(size="48" class="secondary--text") {{ icon }}
            v-card-title(class="justify-center font-weight-light text-h5") {{ getContent(key, 'header') }}
            v-card-text {{ getContent(key, 'text') }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";
import {mdiFaceAgent, mdiHandshake, mdiWalletOutline} from '@mdi/js'

export default {

  name: 'Propositions',
  mixins: [configMixin],
  data() {
    return {
      propositions: {
        partner: mdiHandshake,
        pricing: mdiWalletOutline,
        service: mdiFaceAgent
      }
    }
  },
  methods: {
    getContent(key, alias) {
      if (!this.config.items || !this.config.items[key])
        return null

      return this.config.items[key][alias]
    }
  }
}
</script>
