
<template lang="pug">

  v-card()
    div(class="d-flex flex-sm-row flex-column")
      v-avatar.ma-6.mx-sm-6.mx-auto(:size="220")
        v-img(:src="config.image.url")
      div(class="flex")
        div(class="d-flex justify-space-between")
          v-card-title.text-h5.font-weight-light {{ config.name }}
          v-card-title.grey--text.font-weight-light {{ config.function.text }}
        v-divider
        v-card-subtitle.text-subtitle-1.font-weight-light.pb-2 "{{ config.header }}"
        v-card-text {{ config.text }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

	name: 'www-agent-list',
	mixins: [ configMixin ],
}
</script>

<style scoped>
.v-card__title {
	font-size: 21px;
	font-weight: 300;

}
.v-card__text, .v-card__title {
  word-break: normal; /* maybe !important  */
}
</style>