<template lang="pug">

  v-main
    intro-prominent(:config="config.intro")
    .container.mb-8
      x-list(:items="config.listContacts.items" v-slot="slotProps")
        contact-item(:config="slotProps.config" :translations="config.listContacts.translations")
    schubert-teaser(:config="config.schubertTeaser")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'ContactBody',
  mixins: [configMixin],

  data() {
    return {}
  },
}
</script>
