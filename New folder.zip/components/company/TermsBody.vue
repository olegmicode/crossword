<template lang="pug">

  v-main
    intro-prominent(:config="config.intro")
    .container
      div(v-for="(item, index) in config.terms.items" :key="index")
        h2.text-h5.font-weight-light.mb-4 {{ item.header }}
        p.mb-4(v-for="(paragraph) in getMarkUpParagraphs(item.text)") {{ paragraph.text }}
</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";
import markUpMixin from "../../mixins/xnet/markUpMixin";

export default {
  name: 'TermsBody',
  mixins: [configMixin, markUpMixin],

  data() {
    return {}
  },

}
</script>
