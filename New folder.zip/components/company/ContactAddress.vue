<template lang="pug">

  div
    div.mb-2 {{ config.companyName }}
    div {{ config.address.street }}
    div {{ config.address.postalCode }} {{ config.address.city }}
    div {{ config.address.country }}

</template>

<script>

import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'ContactAddress',
  mixins: [configMixin],
}
</script>
