<template lang="pug">

  v-main
    intro-prominent(:config="config.intro")
    .container.mb-8
      x-list(:items="config.listAgents.items" v-slot="slotProps")
        agent-item(:config="slotProps.config")
    propositions(:config="config.propositions")
    schubert-teaser(:config="config.schubertTeaser")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'AboutUsBody',
  mixins: [configMixin],

  data() {
    return {}
  },
}
</script>
