<template lang="pug">

  v-card()
    div(class="d-flex")
      div(class="flex")
        v-card-title.text-h5.font-weight-light {{ config.source }}
        v-divider
        v-row.mt-4
          v-col(:cols="12" sm="4" md="2")
            v-subheader.py-0 {{ trans('phone') }}
          v-col(:cols="12" sm="8" md="10")
            v-card-text.py-0 {{ config.phone }}
        v-row.mt-4
          v-col(:cols="12" sm="4" md="2")
            v-subheader.py-0 {{ trans('email') }}
          v-col(:cols="12" sm="8" md="10")
            v-card-text.py-0
              a(class="text-decoration-none" :href="'mailTo:' + config.email") {{ config.email }}
        v-row.my-4
          v-col(:cols="12" sm="4" md="2")
            v-subheader.py-0 {{ trans('businessHours') }}
          v-col(:cols="12" sm="8" md="10")
            v-card-text.py-0
              span.mr-2(v-for="(item, index) in config.businessHours" :key="index") {{ item }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'ContactItem',
  mixins: [configMixin],
}
</script>

<style scoped>
.v-card__title {
  font-size: 21px;
  font-weight: 300;

}

.v-subheader {
  height: 24px;
}
</style>