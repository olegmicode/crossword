<template lang="pug">
  v-hover(v-slot="{ hover }")
    v-card(height="325px" :elevation="hover ? 16 : 2"  :class="{ 'on-hover': hover }" @click="reveal=!reveal")
      div(v-if="!reveal" class="fill-height" align="center" justify="center")
        v-avatar.mt-8(:size="200")
          v-img(:src="config.image.url")
        v-card-title.font-weight-light.justify-center()
          h3 {{ config.name }}
      v-expand-transition
        v-card(v-if="reveal" class="transition-fast-in-fast-out v-card--reveal" style="height: 100%;")
          div(class="fill-height" align="center" justify="center")
            v-avatar.mt-4(:size="150")
              v-img(:src="config.image.url")
            v-card-title.font-weight-light.justify-center()
              h3 {{ config.name }}
            v-card-subtitle.pt-2.grey--text.text-uppercase() {{ config.function.text }}
            v-card-text() {{ config.header }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'AgentTeaser',
  data() {
    return {
      reveal: false,
    }
  },
  mixins: [configMixin],

}
</script>

<style scoped>
.v-card__text, .v-card__title {
  word-break: normal; /* maybe !important  */
}
</style>