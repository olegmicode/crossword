<template lang="pug">

  v-container.schubert(fluid v-if="config.show")
    .container.my-8
      v-row
        v-col.pa-6(cols="12" :sm="6" :md="4")
          v-img.mx-auto(src="/schubert/logo-blue.png" contain max-height="150")
        v-col.px-8.text-schubert.text-center.text-sm-left(:cols="12" :sm="6" :md="8")
          p.text-h5.font-weight-light Schubert Travel AG
          p Unser starker und zuverlässiger Partner für Flüge, Hotels, Tickets und Reisen aller Art weltweit. Persönlicher Service und professionelle Beratung.
          v-btn.mt-4.btn-schubert(href="http://www.schubert-travel.ch/" target="_blank") BESUCHEN

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'SchubertTeaser',
  mixins: [configMixin],
}
</script>

<style lang="scss">
.btn-schubert {
  padding: 6px 37px;
  border: 3px solid #E6B800;
  color: #fff;
  text-decoration: none;
  align-items: center !important;
}
.text-schubert {
  color: #fff;
}
</style>
