
// add query as string to url
function appendQuery(url, params) {

    // arguments not valid
    if (!url || typeof params !== 'object')
        return url

    // make query string
    let query = Object.keys(params).map(key => key + '=' + params[key]).join('&')
    if (!query.length)
        return url

    // add query string to url
    return url + (url.includes('?') ? '&' : '?') + query
}

export class sourceService {

    constructor (axios, baseUrl) {
        this.service = this.instance(axios, baseUrl)
    }
    instance (axios, baseUrl) {
        const result = axios.create({
            headers: {
                common: {
                    Accept: 'text/plain, */*'
                }
            }})

        if (baseUrl)
            result.setBaseURL(baseUrl)

        return result
    }
    setToken (token) {

        if (token)
            this.service.setToken(token, 'Bearer')
    }
    route (route, query) {

        // no route defined
        if (!route)
            return null

        // add fixed query
        if (!query)
            return route

        return appendQuery(route, query)
    }

    async get (route, query) {
        return new Promise((resolve, reject) => {

            // run get request
            return this.service.get(this.route(route, query))
                 .then(response => resolve(response.data), reason => reject(reason))
        })
    }
}
