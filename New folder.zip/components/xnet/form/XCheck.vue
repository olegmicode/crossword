<template lang="pug">

  v-checkbox(
    v-model="value"
    :label="config.text"
    v-bind="bindOptions()"
    hide-details="auto"
    @change="onInputChange"
  )

</template>

<script>
import inputMixin from '../../../mixins/xnet/inputMixin.js'

export default {

  name: 'XCheck',
  mixins: [inputMixin],
  props: {},

  data() {
    return {
      default: this.config.default ?? false,
      elements: ['check'],
    }
  },
}
</script>
