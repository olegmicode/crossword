<template lang="pug">
  component(:is="com[config.input]" v-bind="props")
</template>

<script>
import configMixin from "../../../mixins/xnet/configMixin";
import XAutoComplete from '../../../components/xnet/form/XAutoComplete.vue'
import XCheck from '../../../components/xnet/form/XCheck.vue'
import XDate from '../../../components/xnet/form/XDate.vue'
import XNumber from '../../../components/xnet/form/XNumber.vue'

export default {

  name: 'XField',
  mixins: [configMixin],
  props: {
    inherited: {
      type: Object,
      required: false,
      default: () => ({})
    },
  },

  data() {
    return {
      com: {
        'auto-complete': XAutoComplete,
        'number': XNumber,
        'date': XDate,
        'check': XCheck
      }
    }
  },

  computed: {
    props() {
      if (this.inherited)
        return Object.assign({ config: this.config }, this.inherited)
      else
        return {
          config: this.config
        }
    }
  }
}

</script>
