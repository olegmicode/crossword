<template lang="pug">

  v-menu(
    v-model="menu"
    :close-on-content-click="false"
    v-bind="bindOptions('dateMenu')"
  )
    template( v-slot:activator="{ on }" )
      v-text-field(
        v-model="value"
        :label="config.label || ''"
        v-bind="bindOptions('dateText')"
        v-on="on"
      )
    v-date-picker(
      v-model="value"
      :min="minDate"
      :max="maxDate"
      v-bind="bindOptions('datePicker')"
      @change="onInputChange"
      @input="menu = false"
    )

</template>

<script>
import inputMixin from "../../../mixins/xnet/inputMixin";
import {mdiCalendar} from "@mdi/js";

export default {

  name: 'XDate',
  mixins: [inputMixin],
  data() {
    return {
      menu: false,
      minDate: this.$getIsoDate(this.config.minDate),
      maxDate: this.$getIsoDate(this.config.maxDate),
      elements: ['dateMenu', 'dateText', 'datePicker'],
      options: {
        dateMenu: {
          transition: "scale-transition",
          offsetY: true,
          minWidth: "auto"
        },
        dateText: {
          prependInnerIcon: mdiCalendar,
          readonly: true,
          hideDetails: true
        },
        datePicker: {
          scrollable: true,
          noTitle: true,
          localeFirstDayOfYear: 1
        }
      }
    }
  },

  methods: {

    setLocalValue() {
      if (!this.model[this.config.model])
        this.value = null
      else
        this.value = this.$getIsoDate(this.model[this.config.model].date)
    },
    setModelValue() {
      if (!this.model[this.config.model])
        this.model[this.config.model] = {}
      this.model[this.config.model].date = this.value
    },

    checkValidationMinDate(rule) {
      // todo: implement min-date check
      return true
    },
    checkValidationMaxDate(rule) {
      // todo: implement min-date check
      return true
    }

  },
}
</script>
