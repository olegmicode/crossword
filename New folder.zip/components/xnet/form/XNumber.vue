<template lang="pug">

  v-text-field(
    type="number"
    :name="config.model"
    v-model="value"
    :rules="rules"
    :placeholder="config.placeholder"
    v-bind="bindOptions()"
    hide-details="auto"
    @input="onInputChange"
    :min="config.minValue ? config.minValue : 1"
    :max="config.maxValue ? config.maxValue : 99"
  )

</template>

<script>
import inputMixin from '../../../mixins/xnet/inputMixin.js'

export default {

  name: 'XNumber',
  mixins: [inputMixin],

  data() {
    return {
      input: true,
      default: this.config.default ?? 0,
      elements: ['number'],
      options: {
        number: {
          prefix: this.config.prefix,
          suffix: this.config.suffix,
          showButtons: true
        }
      }
    }
  },

  methods: {
    getValidationMinValue() {
      return v => v >= this.config.validations.minValue
          || this.config.messages['validation.minValue'].replace(':value', this.config.validations.minValue)
    },
    getValidationMaxValue() {
      return v => v <= this.config.validations.maxValue
          || this.config.messages['validation.maxValue'].replace(':value', this.config.validations.maxValue)
    }
  }
}
</script>
