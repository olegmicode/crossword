<template lang="pug">

  v-autocomplete(
    :label="config.label || ''"
    :name="config.model"
    v-model="value"
    :placeholder="config.placeholder"
    :rules="rules"
    v-bind="bindOptions()"
    @input="onInputChange"
    :v-on:item-select="onInputChange"
    :v-on:clear="onInputChange"
    :items="list"
    :loading="loading"
    hide-details="auto"
    item-text="formatted"
    item-value="slug"
    return-object
    :filter="queryItem"
  )

</template>
<script>
import inputMixin from '../../../mixins/xnet/inputMixin'
import sourceMixin from "../../../mixins/xnet/sourceMixin";

export default {

  name: 'XAutoComplete',
  mixins: [inputMixin, sourceMixin],
  props: {},
  data() {
    return {
      list: [],
      filters: null,
      elements: ['autoComplete'],
      options: {
        autoComplete: {
          autoSelectFirst: true,
          clearable: true,
          hideNoData: true,
          prefix: this.config.prefix,
          suffix: this.config.suffix
        }
      },
    }
  },
  mounted() {

    this.filters = this.getFilters()
    this.refreshList()
  },
  methods: {
    setDependencies() {
      this.refreshList()
    },
    refreshList(force = false) {

      // list in config
      if (this.config.list)
        return this.setFromConfig()

      // no source defined
      if (!this.config.source)
        return

      // no filters defined
      if (!this.filters)
        return this.getFromSource(this.config.source)

      // filter query, if null, values missing
      let query = this.getFilterQuery()
      if (!query)
        return this.resetList()

      // load new list
      return this.getFromSource(this.config.source, query, force)
    },
    resetList() {
      this.query = null
      this.list = []
      this.suggestions = []
    },
    setFromConfig() {
      this.list = this.config.list
    },
    setFromSource(data) {
      this.list = this.formatItems(data, this.config.format)
    },
    formatItems(result, format) {

      // no items
      if (!result || !Array.isArray(result)
          || !result.length)
        return []

      // add formatted text
      result.forEach(function (item) {
        item.formatted = eval(format)
      })

      return result
    },

    getFilters() {

      // no filter
      if (!this.config.filter)
        return null

      // associative array
      if (typeof this.config.filter !== 'string')
        return this.config.filter

      // string filter key=attr
      let parts = this.config.filter.split('=')
      let result = []
      result[parts[0]] = parts[1]
      return result
    },
    getFilterQuery() {

      // evaluate model values for each
      const result = {}
      let self = this
      let value = null
      if (Object.keys(this.filters).every(
          key => {
            // no value
            if (!(value = self.getFilterValue(self.filters[key])))
              return false

            // add value
            result[key] = value
            return true
          })
      ) return result

      // else return empty
      return null
    },
    getFilterValue(attr) {

      let result = this.model

      if (!attr.split('.').every(key => {

        if (result[key] == null)
          return null

        result = result[key]
        return true
      })
      ) return null

      return result
    },

    queryItem(item, query) {

      // query by formatted text
      if (!this.config.keyWords)
        return this.queryText(item.formatted, query)

      // query by keywords
      return this.config.keyWords
          .split(',')
          .some(keyWord => this.queryText(eval('item.' + keyWord), query))
    },
    queryText(str, query) {

      // no query
      if (!query || !query.length)
        return true

      // not string
      if (typeof str !== 'string')
        return false

      // query
      return str.toLowerCase().includes(query.toLowerCase())
    },
  },
}
</script>
