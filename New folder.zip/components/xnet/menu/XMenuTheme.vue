
<template lang="pug">

  v-btn(icon v-on:click="toggleTheme" :text="text" small class="ml-1")
    v-icon {{ $vuetify.theme.isDark ? svgWhiteBalanceSunny : svgMoonWaningCrescent }}

</template>

<script>
import { mdiMoonWaningCrescent, mdiWhiteBalanceSunny } from '@mdi/js'

export default {

	name: 'XMenuTheme',
  props: {
    text: {
      type: Boolean,
      required: false,
      default: true
    },
  },
  data() {
    return {
      svgMoonWaningCrescent: mdiMoonWaningCrescent,
      svgWhiteBalanceSunny: mdiWhiteBalanceSunny
    }
  },
  methods: {
    toggleTheme() {
	    this.$vuetify.theme.dark = !this.$vuetify.theme.dark
    }
  }
}
</script>
