
<template lang="pug">

      v-menu(v-model="open")
        template(v-slot:activator="{ on, attrs }")
          v-btn(icon color="primary" text v-bind="attrs" v-on="on" small class="ml-2")
            x-flag(v-if="flag" rounded="sm" :size="16" :country="config.country")
            span(v-if="!flag") {{ config.label }}
        v-list(nav :dense="dense")
          v-list-item-group
            v-list-item(v-for="(item, index) in config.items" :key="index" :to="item.route")
              x-flag-list(v-if="flag" rounded="sm" :size="16" :country="item.country")
              v-list-item-title {{ item.text }}

</template>

<script>
import configMixin from "../../../mixins/xnet/configMixin";

export default {

	name: 'XMenuLang',
  mixins: [configMixin],
	props: {
	  dense: {
	    type: Boolean,
      required: false,
      default: false
    },
	  flag: {
	    type: Boolean,
      required: false,
      default: false
    }
  },
	data() {
		return {
      open: true
    }
	},
  mounted() {
    this.open = false
  }
}
</script>
