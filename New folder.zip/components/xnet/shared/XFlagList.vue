<template lang="pug">

  v-list-item-avatar(:height="height"
    :width="computedWidth" :min-width="computedWidth"
    :tile="tile" :rounded="rounded")
    v-img(:src="source")

</template>

<script>
export default {

  name: 'XFlagList',
  props: {
    country: {
      type: String,
      required: true
    },
    tile: {
      type: Boolean,
      required: false,
      default: false
    },
    rounded: {
      type: String,
      required: false,
      default: undefined
    },
    size: {
      type: Number,
      required: false,
      default: 20
    },
    width: {
      type: Number,
      required: false
    }
  },
  computed: {
    computedWidth() {
      return `${this.width ?? (this.size * 4 / 3)}px`
    },
    height() {
      return `${this.size}px`
    },
    source() {
      return `/flags/4x3/${this.country}.svg`
    }
  }
}
</script>
