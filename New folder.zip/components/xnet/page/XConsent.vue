<template lang="pug">

  v-bottom-sheet(:value="$config.gdprAcceptEnabled && !gdprAccepted" hide-overlay persistent)
    v-sheet.text-center.pa-8
      div.mb-4
        span {{ config.message }}
        a.ma-2(v-if="config.privacy" :href="config.privacy.route") {{ config.privacy.label }}
      div
        v-btn.mr-2(color="primary" @click="setAccepted(true)") {{ config.accept.label }}
        v-btn(v-if="config.deny" text @click="setAccepted(false)") {{ config.deny.label }}

</template>

<script>
// todo: nuxtlink line 7

import configMixin from "../../../mixins/xnet/configMixin"

export default {

  name: 'XConsent',
  mixins: [configMixin],

  data() {
    return {
      gdprAccepted: false,
      cookieKey: 'GDPR:accepted',
    };
  },

  created() {
    if (this.isAccepted())
      this.gdprAccepted = true
  },

  methods: {

    isAccepted() {
      if (process.browser) {
        return $cookies.get(this.cookieKey)
      }
    },

    setAccepted(value) {
      if (process.browser) {
        this.gdprAccepted = value
        $cookies.set(this.cookieKey, value ? 'true' : 'false')
      }
    },
  }
}
</script>