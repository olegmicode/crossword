<template lang="pug">

  v-row()
    v-col(v-bind="bindOptions('columns')"
      v-for="(item, index) in items" :key="index")
      slot(v-bind:config="item")

</template>

<script>
import optionsMixin from "../../../mixins/xnet/optionsMixin";

export default {

  name: 'XList',
  mixins: [optionsMixin],
  props: {
    items: {
      type: Array,
      required: false,
      default: () => ([])
    },
  },

  data() {
    return {
      elements: ['columns'],
      options: {
        columns: {cols: 12}
      }
    }
  },
}
</script>
