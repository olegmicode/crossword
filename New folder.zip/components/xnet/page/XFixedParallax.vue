<template lang="pug">

  div(class="d-flex justify-center align-center parallax"
    :style="customStyle")
    slot

</template>

<script>
export default {
  name: 'XFixedParallax',
  props: {
    height: {
      type: Number|String,
      default: 600
    },
    src: {
      type: String,
      default: '',
      required: true
    }
  },
  data() {
    return {}
  },
  computed: {
    customStyle() {
      return {
        height: `${this.height}px`,
        backgroundImage: `url(${this.src})`,
        backgroundSize: `auto ${this.height + 128}px`
      }
    }
  }
}
</script>

<style>
.parallax {
  background-attachment: fixed;
  background-position: center top;
  background-repeat: no-repeat;
}
</style>
