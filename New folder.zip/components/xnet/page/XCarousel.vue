<template lang="pug">

  v-carousel(v-bind="bindRootOptions()")
    v-carousel-item(v-for="(group, g) in groups" :key="g")
      v-row.mx-n3(v-bind="bindOptions('row')")
        v-col.pa-4(:cols="cols" v-for="(item, i) in group" :key="i")
          slot(v-bind:config="item")

</template>

<script>
import optionsMixin from "../../../mixins/xnet/optionsMixin";

export default {

  name: 'XCarousel',
  mixins: [ optionsMixin ],
  props: {
    items: {
      type: Array,
      required: false,
      default: () => ([])
    },
  },

  data() {
    return {
      elements: [ 'root', 'item', 'row', 'col', 'columns' ],
      options: {
        root: {
          light: true,
          hideDelimiterBackground: true,
          showArrowsOnHover: true,
          cycle: false,
          interval: 6000
        },
        row: {
          dense: false,
        }
      }
    }
  },

  computed: {
    cols() {
      // default
      let result = 12

      // cols not defined
      if (!this.options.columns)
        return result

      // get by breakpoint
      return this.$getBreakpointValue(this.$vuetify.breakpoint, this.options.columns, result)
    },
    groups() {
      let max = 12/this.cols
      const result = []
      if (!this.items)
        return result

      let group = [];
      this.items.forEach(item => {
        group.push(item)
        if (group.length >= max) {
          result.push(group)
          group = []
        }
      })

      if (group.length)
        result.push(group)

      return result
    }
  },
  methods: {
    bindRootOptions() {

      // default case
      if (this.groups.length >1)
        return this.options.root

      // override
      const result = this.$assignToObject({}, this.options.root)
      result.hideDelimiters = true
      result.showArrows = false

      return result
    }
  }
}
</script>
