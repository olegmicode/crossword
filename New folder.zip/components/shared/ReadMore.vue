<template lang="pug">

  .container(v-if="config.moreLinks")
    .my-8.text-h4.font-weight-light {{ trans('readMore') }}
    v-btn.mr-2.mb-4.ellipsis(xLarge
      v-for="(item, index) in config.moreLinks" :key="index"
      :to="item.route") {{ item.label }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'ReadMore',
  mixins: [configMixin],
  data() {
    return {}
  }
}
</script>

<style>
.ellipsis span {
  text-overflow: ellipsis;
  width: 100%;
  display: inline-block;
  white-space: nowrap;
  overflow: hidden;
}
</style>
<style scoped>
.v-btn {
  max-width: 100%;
}
.v-card__title {
  font-size: 21px;
  font-weight: 300;

}
.v-card__text, .v-card__title {
  word-break: normal; /* maybe !important  */
}
</style>