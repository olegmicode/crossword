
<template lang="pug">

  v-container.mb-12
    v-row
      v-col(:cols="6" :md="3")
        destination-footer(:config="config.children.destinations.children.top")
      v-col(:cols="6" :md="3")
        div(class="px-4")
          v-subheader(class="px-0 mb-2") {{ trans('pageLinks') }}
          page-links(:config="config.pageLinks")
      v-col(:cols="12" :md="6")
        v-row
          v-col(:cols="6")
            v-subheader {{ trans('contact') }}
            contact-address.px-4(:config="config.contact")
          v-col(:cols="6")
            v-subheader {{ trans('businessHours') }}
            div.px-4
              div {{ trans('monday') }} - {{ trans('friday') }}:
              div(v-for="(item, index) in config.contact.businessHours" :key="index") {{ item }}
          v-col(:cols="12")
            div.px-4
              div.mb-1
                v-icon(dense class="mr-1") {{ svgPhone }}
                | {{ config.contact.phone }}
              div
                a(class="text-decoration-none" :href="'mailTo:' + config.contact.email")
                  v-icon(dense class="mr-1") {{ svgEmail }}
                  | {{ config.contact.email }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";
import { mdiPhone, mdiEmailOutline } from '@mdi/js'

export default {

	name: 'AppFooter',
  mixins: [ configMixin ],
  data() {
    return {
      svgPhone: mdiPhone,
      svgEmail: mdiEmailOutline
    }
  }
}
</script>
