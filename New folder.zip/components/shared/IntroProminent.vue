<template lang="pug">

  .container
    .my-8
      h1.text-h4.font-weight-light.mb-4 {{ config.header }}
      p(v-if="config.text") {{ config.text }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'IntroProminent',
  mixins: [configMixin],
}
</script>
