<template lang="pug">
  v-menu(
    v-model="open"
    tile
    offset-y
    min-width="100%"
    transition="scroll-y-transition"
    allow-overflow
    fixed
    :close-on-content-click="false"
    max-height="420"
    attach=".v-toolbar__extension"
    :nudge-top="80"
  )

    template(v-slot:activator="{ on, attrs }")
      v-btn.d-none.d-sm-block.text-h6(tile :ripple="false" color="primary" text v-bind="attrs" v-on="on" @mouseenter="open = true" style="height: 100%;")
        span {{ trans('explore') }}
        v-icon(small v-text="open ? svgMenuUp : svgMenuDown")
      v-app-bar-nav-icon.d-flex.d-sm-none(v-bind="attrs" v-on="on")
    v-sheet(class="d-flex" min-height="420")
      v-list.d-block.d-sm-none(:dense="dense" nav style="width: 100%;")
        v-list-group(class="" v-for="(nav, i) in navs" :key="`nav-${i}`")
          template(v-slot:activator)
            v-list-item-title {{ nav.label }}
          v-list-group(no-action sub-group v-for="(group, i) in nav.children" :key="`group-${i}`")
            template(v-slot:activator)
              v-list-item-content
                v-list-item-title {{ group.label }}
            v-list-item(v-for="(item, i) in group.items" :key="`group-item-${i}`" link :to="item.route")
              x-flag-list(v-if="flag" rounded="sm" :size="16" :country="item.country")
              v-list-item-title {{ item.label }}
      v-tabs.d-none.d-sm-flex(v-model="tab" vertical)
        v-tab(v-for="(nav, i) in navs" :key="`nav-${i}`" class="justify-start") {{ nav.label }}
        v-tabs-items(v-model="tab" vertical)
          v-tab-item(v-for="(nav, i) in navs" :key="`nav-tab-${i}`")
            v-expansion-panels(accordion flat :value="0")
              v-expansion-panel(v-for="(group, j) in nav.children" :key="`group-${j}`")
                v-expansion-panel-header {{ group.label }}
                v-expansion-panel-content
                  v-row(dense)
                    v-col(:cols="12 / columns" v-for="(item, k) in group.items" :key="`group-item-${k}`")
                      v-list-item(min-height="32" :dense="dense" :to="item.route")
                        x-flag-list(v-if="flag" rounded="sm" :size="16" :country="item.country")
                        v-list-item-title {{ item.label }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";
import {mdiMenuDown, mdiMenuUp} from '@mdi/js'

export default {
  name: 'MenuNavigation',
  mixins: [configMixin],
  props: {
    flag: {
      type: Boolean,
      required: false,
      default: true
    },
    dense: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data: () => ({
    columnsPerBreakpoint: {xl: 6, lg: 4, md: 3, sm: 3, xs: 2},
    tab: 0,
    navKeys: ['destinations', 'routes', 'vehicles'],
    navs: [],
    open: true,
    svgMenuUp: mdiMenuUp,
    svgMenuDown: mdiMenuDown
  }),
  computed: {
    columns() {
      let result = 1
      Object.keys(this.columnsPerBreakpoint).some(key => {
        if (this.$vuetify.breakpoint[key])
          return (result = this.columnsPerBreakpoint[key])
      })

      return result
    }
  },
  created() {
    this.parseNavs()
    this.navs.forEach((nav, i) => {
      if (nav.active)
        this.tab = i
    })
  },
  mounted() {
    this.open = false
  },
  methods: {
    parseNavs() {
      this.navs = this.navKeys.map((key) => {
        return this.config.children[key]
      })
    },
  }
}
</script>

<style lang="scss">
#app-header {
  .v-toolbar__content {
    padding-top: 0;
    padding-bottom: 0;
    height: 100%;
  }

  .v-toolbar__extension .v-menu__content {
    left: 0 !important;
    top: 0 !important;
    box-shadow: 0px 10px 10px #0008;
    border-top: solid 1px rgba(0, 0, 0, 0.12);
  }

  .v-btn:before {
    background: transparent !important;
  }
}
</style>