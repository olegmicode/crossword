<template lang="pug">
  v-app-bar(id="app-header" app fixed short shrink-on-scroll class="d-flex flex-column justify-center" :extension-height="1")
    template(v-slot:extension)
    v-row.align-center.my-0.height-100
      v-col.d-flex.flex-grow-0.flex-sm-grow-1.align-center.py-0.height-100
        menu-navigation(:config="config.navigation" flag dense)
      v-col.text-center.py-0.height-100
        a.d-flex.align-center.height-100(:href="config.navigation.branding.route")
          v-img.mx-auto(contain :src="config.navigation.branding.logo" height="90%" max-height="60")
      v-col.py-0
        .d-none.d-sm-flex.flex-column
          div.d-flex.justify-end.flex-wrap
            div
              span.caption.text-h6
                v-icon(dense='') {{ svgPhone }}
                |  {{ config.navigation.contact.phone }}
              a(class="text-decoration-none mt-n1" :href="'mailTo:' + config.navigation.contact.email")
                v-icon(class="ml-2") {{ svgEmail }}
            div.mt-n2.mt-md-0
              x-menu-lang(:config="config.navigation.languages" dense flag)
              x-menu-theme
          menu-links(v-if="!shrinked" :config="config.navigation.pageLinks")

</template>

<script>
// todo: nuxtlink line 8

import configMixin from "../../mixins/xnet/configMixin";
import {mdiEmailOutline, mdiPhone} from '@mdi/js'

export default {

  name: 'AppHeader',
  mixins: [configMixin],
  props: {},
  data() {
    return {
      shrinked: false,
      expanded: false,
      svgPhone: mdiPhone,
      svgEmail: mdiEmailOutline
    }
  },
  computed: {},
  mounted() {
    window.onscroll = (e) => {
      if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
        this.shrinked = true
      } else {
        this.shrinked = false
      }
    }
  },
  methods: {
    expand() {
      this.expanded = !this.expanded
    }
  }
}
</script>
<style lang="scss">
#app-header {
  .height-100 {
    height: 100%;
  }

  .v-toolbar__extension {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }

  .expanded-header {
    position: absolute;
    top: 0;
    left: 0;
  }
}

</style>
