<template lang="pug">

  .d-none.d-md-block.text-right
    span(v-for="(item, index) in items()" :key="index")
      nuxt-link.px-1.caption(:to="item.route") {{ item.label }}

</template>

<script>

import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'MenuLinks',
  mixins: [configMixin],
  props: {},
  data() {
    return {
      links: ['contact', 'aboutUs', 'blogs']
    }
  },
  methods: {
    items() {
      if (!this.config)
        return null

      let result = []
      this.links.forEach((key, index) => {
        if (!this.config[key]) return
        result.push(this.config[key])
      })

      return result
    }
  }
}
</script>
