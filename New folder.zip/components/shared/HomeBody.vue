<template lang="pug">

  v-main
    search-container(:config="config.search")
    intro-prominent(:config="config.intro")
    destination-teasers(:config="config.topDestinations")
    propositions(:config="config.propositions")
    agent-teasers(:config="config.teaseAgents")
    blog-teasers(:config="config.latestBlogs")
    schubert-teaser(:config="config.schubertTeaser")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'HomeBody',
  mixins: [configMixin],
}
</script>
