<template lang="pug">
  v-row
    v-col(:cols="12" v-for="(item, index) in items()" :key="index" class="py-1")
      nuxt-link(:to="item.route" class="text-decoration-none")
        span {{ item.label }}
</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'PageLinks',
  mixins: [configMixin],
  props: {},
  data() {
    return {
      links: ['contact', 'aboutUs', 'blogs', 'termsOfService', 'privacyPolicy', 'cookiePolicy']
    }
  },
  methods: {
    items() {
      if (!this.config)
        return null

      let result = []
      this.links.forEach((key, index) => {
        if (!this.config[key]) return
        result.push(this.config[key])
      })

      return result
    }
  }
}
</script>
