<template lang="pug">

  v-row.mt-12.mb-8
    v-col.mb-sm-2.text-h4.font-weight-light(:cols="12" :sm="8") {{ config.header }}
    v-col.mb-sm-2.text-sm-right(v-if="config.button" :cols="12" :sm="4")
      v-btn(:to="config.button.route" right xLarge) {{ config.button.label }}
    v-col(v-if="config.text") {{ config.text }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'IntroTeaser',
  mixins: [configMixin],
}
</script>
