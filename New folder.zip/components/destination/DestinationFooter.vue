<template lang="pug">
  div
    v-subheader(class="mb-2") {{ config.label }}
    v-row
      v-col.py-0.mt-1(:cols="12" v-for="(item, index) in config.items" :key="index")
        nuxt-link.text-decoration-none(:to="item.route")
          x-flag-list.mt-1(:country="item.country" rounded="sm" :size="16")
          span {{ item.label }}

</template>

<script>

import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'DestinationFooter',
  mixins: [configMixin],

  methods: {
    items() {
      if (!this.config.items)
        return null

      let result = []
      this.config.items.forEach((item, index) => {
        if (!item.top) return
        result.push(item)
      })

      return result
    }
  }

}
</script>