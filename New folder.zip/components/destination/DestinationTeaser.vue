<template lang="pug">
  v-hover(v-if="config.teaserImage" v-slot="{ hover }")
    v-card(height="270px" :elevation="hover ? 16 : 2"  :class="{ 'on-hover': hover }" :to="config.route")
      div(class="fill-height" align="center" justify="center")
        v-img(:src="config.teaserImage.url" height="176px")
        x-flag(:size="72" :country="config.country.slug")
        v-card-subtitle.pt-2.text-h6.font-weight-light {{ config.text }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'DestinationTeaser',
  mixins: [configMixin],
}
</script>

<style scoped>
.v-avatar {
  margin-top: -36px;
  border: solid 4px white;
}
</style>