<template lang="pug">

  v-main
    search-container(:config="config.search")
    intro-prominent(:config="config.intro")
    .container
      x-list(:items="config.listDestinations.items"
        :inheritOptions="listOptions" v-slot="slotProps")
        destination-teaser(:config="slotProps.config")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'DestinationListBody',
  mixins: [configMixin],

  data() {
    return {
      listOptions: {
        columns: { cols:12, sm:6, md:4, lg:3, xl:2 }
      }
    }
  },
}
</script>
