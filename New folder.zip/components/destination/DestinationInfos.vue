<template lang="pug">

  .container
    v-row
      v-col(:cols="12" :md="4" v-for="(item, i) in config.infos" :key="i")
        v-card(height="100%")
          v-card-title(style="background:#b4332f")
            h3.font-weight-light(style="color:#fff") {{ item.header }}
          v-divider
          v-card-text(class="flex")
            p {{ item.text }}
            p(v-for="(link, k) in item.links" :key="k")
              span {{ linkPreText(link) }}
              a(:href="link.url" rel="noopener noreferrer" class="text-decoration-none" target="_blank") {{ linkEmbedText(link) }}
              span {{ linkPostText(link) }}

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'DestinationInfos',
  mixins: [configMixin],
  props: {},
  data() {
    return {}
  },
  computed: {},
  methods: {
    linkPreText(link) {
      if (!link.text) return null
      return link.text.substr(0, link.text.search("<<"))
    },
    linkEmbedText(link) {
      if (!link.text) return null
      const p1 = link.text.search("<<")
      return link.text.substr(p1 + 2, link.text.search(">>") - p1 - 2)
    },
    linkPostText(link) {
      if (!link.text) return null
      return link.text.substr(link.text.search(">>") + 2)
    }
  }

}
</script>
