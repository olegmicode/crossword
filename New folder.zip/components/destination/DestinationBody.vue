<template lang="pug">

  v-main
    search-container(:config="config.search")
    intro-prominent(:config="config.intro")
    destination-infos(:config="config.infos")
    route-teasers(v-if="config.teaseRoutes" :config="config.teaseRoutes")
    vehicle-teasers(v-if="config.teaseVehicles" :config="config.teaseVehicles")
    read-more(v-if="config.readyForMore" :config="config.readyForMore")
</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'DestinationBody',
  mixins: [configMixin],

  data() {
    return {}
  },
}
</script>
