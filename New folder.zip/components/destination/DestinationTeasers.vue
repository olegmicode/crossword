<template lang="pug">

  .container
    intro-teaser(:config="config.heading")
    x-carousel(:items="config.items"
      :inheritOptions="options" v-slot="slotProps")
      destination-teaser(:config="slotProps.config")

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {

  name: 'DestinationTeasers',
  mixins: [configMixin],
  data() {
    return {
      options: {
        root: {height: 340},
        row: {dense: true},
        columns: {cols: 6, md: 4, lg: 3, xl: 2}
      },
    }
  },

}
</script>
