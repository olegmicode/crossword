<template lang="pug">

  v-main
    v-container
      v-stepper(v-model="el")
        v-stepper-header
          v-stepper-step(:complete="el > 1" step="1") Result
          v-divider
          v-stepper-step(:complete="el > 2" step="2") Customize
          v-divider
          v-stepper-step(:complete="el > 3" step="3") Book
        v-stepper-items
          v-stepper-content(step="1")
            v-card(class="mb-12" color="grey lighten-1" height="200px")
            v-btn(color="primary" @click="el = 2") Continue
            v-btn(text) Cancel
          v-stepper-content(step="2")
            v-card(class="mb-12" color="grey lighten-1" height="200px")
            v-btn(color="primary" @click="el = 3") Continue
            v-btn(text) Cancel
          v-stepper-content(step="3")
            v-card(class="mb-12" color="grey lighten-1" height="200px")
            v-btn(color="primary" @click="el = 1") Continue
            v-btn(text) Cancel

</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";
import markUpMixin from "../../mixins/xnet/markUpMixin";

export default {
  name: 'BookingBody',
  mixins: [configMixin],

  data() {
    return {
      el: 1
    }
  },

}
</script>
