<template lang="pug">
  x-fixed-parallax(:height="600" :src="config.background")
    search-form(:config="config.form")
</template>

<script>
import configMixin from "../../mixins/xnet/configMixin";

export default {
  name: 'SearchContainer',
  mixins: [configMixin],
}
</script>
