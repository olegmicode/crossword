<template lang="pug">
    v-card(class="pa-8 align-self-center" :color="bgColor" max-width="900")
      search-form-warning(:warning="warning" :searchTips="searchTips")
      v-form(:ref="form.ref")
        // heading
        h2.text-h3.text-center.font-weight-light.mb-6 {{ config.heading.header }}
        // section route
        v-row
          v-col(v-for="(item, index) in sections.route" cols="12" sm="6" :key="index" v-if="isFieldCondition(item)")
            x-field(:config="config.fields[item]" :inherited="fieldInherit")
        // section dates and passengers
        v-row
          v-col(v-for="(item, index) in sections.datePax" cols="6" sm="3" :key="index" v-if="isFieldCondition(item)")
            x-field(:config="config.fields[item]" :inherited="fieldInherit")
        // submit button
        .text-center.text-sm-left.mt-8
          v-btn(@click="handleSubmit()" xLarge color="primary" :loading="form.submitting") {{ config.submit.label }}
</template>

<script>
import searchMixin from "../../mixins/bmr/searchMixin";
import { mdiCloudAlert } from '@mdi/js';

export default {
  name: 'SearchForm',
  mixins: [searchMixin],
  data() {
    return {
      svgCloudAlert: mdiCloudAlert,
      sections: {
        route: [ 'pickUpCity', 'oneWay', 'dropOffCity' ],
        datePax: [ 'pickUpDate', 'dropOffDate', 'passengers', 'driverAge' ],
      },
      inputOptions: {
        all: {
          solo: true,
          dense: true,
          outlined: true
        }
      },
    }
  },

  computed: {
    bgColor () {
      return this.$vuetify.theme.dark
        ? 'rgba(0,0,0,0.5)'
        : 'rgba(255,255,255,0.5)'
    }
  },

  methods: {
    redirectQuotes(query) {
      window.location.href = 'https://book.world-wide-wheels.com/quotes?' + query
    }
  }
}
</script>
