<template lang="pug">
      v-alert.mb-8(v-if="warning" type="error" :icon="svgCloudAlert" prominent)
        p {{ warning }}
        ul(v-if="searchTips.length")
          li(v-for="(item, index) in searchTips") {{ item }}
</template>

<script>
import { mdiCloudAlert } from '@mdi/js';

export default {
  name: 'SearchFormWarning',

  props: {
    warning: {
      type: String,
      required: false
    },
    searchTips: {
      type: Array,
      required: false,
      default: []
    },
  },

  data() {
    return {
      svgCloudAlert: mdiCloudAlert
    }
  },
}
</script>
