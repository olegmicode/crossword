import Vue from 'vue'

import BmrMapDirections from "../../components/bmr/maps/BmrMapDirections.js";

Vue.component('bmr-map-directions', BmrMapDirections)
