import Vue from 'vue'
import * as VueGoogleMaps from "vue2-google-maps";

export default async ( { $config: { googleApiKey } } ) => {
  Vue.use(VueGoogleMaps, {
    load: {
      key: googleApiKey,
      libraries: "places"
    }
  });
}