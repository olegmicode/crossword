import { sourceService } from '../../components/xnet/services/source.service'

export default ({ $axios, $config: { bmrURL } }, inject) => {

    const bmr = new sourceService($axios, bmrURL)
    inject('bmr', bmr)
}