import Vue from "vue"
import VueCookies from 'vue-cookies'

export default ( { $config: { cookieExpiryDays }, req } ) => {
    // use cookie
    Vue.use(VueCookies)
    Vue.$cookies.config(cookieExpiryDays)
}
