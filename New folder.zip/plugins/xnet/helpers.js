import Vue from 'vue'

// run a function by string
Vue.prototype.$callFunction = (context, funct, payload) => {
    if (context[funct] === undefined) return
    return context[funct].call(context, payload);
}

// set upper case for first letter
Vue.prototype.$upperCaseFirst = (str) => {
    if (!str) return str
    return str.substr(0,1).toUpperCase() + str.substr(1)
}

// get Breakpoint value
Vue.prototype.$getBreakpointValue = (breakpoint, object, value = null) => {

    if (typeof object === 'string')
        return object

    if (typeof object !== "object")
        return value

    const breakpoints = [ 'xs', 'sm', 'md', 'lg', 'xl' ]
    breakpoints.some(item => {
        if (object[item])
            value = object[item]
        if (breakpoint.name === item)
            return true
    })

    return value
}

// get date object in ISO format
Vue.prototype.$getIsoDate = (obj, long = false) => {

    let date = Vue.prototype.$parseToDate(obj)
    if (!date) return null

    let result = date.toISOString()

    return long ? result : result.substr(0,10)
}

// get date object
Vue.prototype.$parseToDate = (obj) => {

    // nothing
    if (!obj)
        return null

    // already a date
    if (obj instanceof Date)
        return obj

    // object with date attr
    if (typeof obj === 'object' && obj.date)
        return Vue.prototype.$parseToDate(obj.date)

    // not string
    if (typeof obj !== 'string')
        return null

    // parse to date
    let parts = obj.substr(0,10).split('-');
    return new Date(Date.UTC(parts[0], parts[1]-1, parts[2]));
}

// set upper case for first letter
Vue.prototype.$isObjectEmpty = (obj) => {
    if (!obj) return true
    if (typeof obj !== 'object') return false
    return Object.keys(obj).length === 0
}

// get nested value of object
Vue.prototype.$getObjectPath = (obj, path) => {

    if (!path) return obj

    let result = obj
    if (!Array.isArray(path))
        path = path.split('.')

    if (path.every(key => {

        if (result[key] === undefined)
            return false

        result = result[key]
        return true
    })) return result

    return undefined
}

// get nested value of object
Vue.prototype.$getObjectAttrs = (result, obj, attrs) => {

    if (typeof obj !== 'object')
        return result

    if (!Array.isArray(attrs))
        return result

    attrs.forEach(key => { if (obj[key]) result[key] = obj[key] })

    return result
}

// convert camel case / snake case
Vue.prototype.$toCamelCase = (str) => {
    return str.replace(/([-_]\w)/g, g => g[1].toUpperCase())
}
Vue.prototype.$toSnakeCase = (str, divider = '-') => {
    return str.split(/(?=[A-Z])/).join(divider).toLowerCase()
}

Vue.prototype.$joinSpaced = (...args) => {

    if (!Array.isArray(args))
        return ''

    const result = []
    args.forEach(text => { if (text) result.push(text) })

    return result.join(' ')
}

Vue.prototype.$assignToObject = (result, source, short) => {

    if (!result) result = {}

    // no source
    if (!source)
        return result

    // short cut
    if (typeof source === 'string')
        result[short] = source

    // assign values
    else if (typeof source === 'object')
        Object.assign(result, source)

    return result
}

Vue.prototype.$sortObjectArray = (array, key, order) => {

    function compareValues(key, order = 'asc') {
        return function innerSort(a, b) {
            if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
                // property doesn't exist on either object
                return 0;
            }

            const varA = (typeof a[key] === 'string')
                ? a[key].toUpperCase() : a[key];
            const varB = (typeof b[key] === 'string')
                ? b[key].toUpperCase() : b[key];

            let comparison = 0;
            if (varA > varB) {
                comparison = 1;
            } else if (varA < varB) {
                comparison = -1;
            }
            return (
                (order === 'desc') ? (comparison * -1) : comparison
            );
        };
    }

    array.sort(compareValues(key, order))
    return array
}

