import { sourceService } from '../../components/xnet/services/source.service'

export default ({ $axios, $config: { schemaURL, apiURL } }, inject) => {

    const schema = new sourceService($axios, schemaURL)
    inject('schema', schema)

    const api = new sourceService($axios, apiURL)
    inject('api', api)
}