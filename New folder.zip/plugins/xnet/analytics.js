import Vue from "vue"
import VueGtag from "vue-gtag"

export default ( { $config: { googleAnalyticsId, googleAnalyticsEnabled }, req } ) => {

    const gdprAccepted = 'ndef'
    // get from cookies...
    // const gdprAccepted = $cookies.get('GDPR:accepted') ??

    Vue.use(VueGtag, {
        config: { id: googleAnalyticsId },
        bootstrap: !(gdprAccepted === 'false'),
        enabled: gdprAccepted === 'true' && googleAnalyticsEnabled,
    })
}
