import http from 'http'

export default function ({ store, route }) {
  const url = 'landing?route=' + route.path.substr(1)

  return store.dispatch('config/getConfig', url)
}