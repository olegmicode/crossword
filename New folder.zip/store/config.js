export const state = () => ({
  config: null
})

export const actions = {
  async getConfig ({ commit }, url) {
    try {
      const response = await this.$schema.get(url)

      commit('SET_CONFIG', response)
    } catch (err) {
    }
  }
}

export const mutations = {
  SET_CONFIG(state, config) {
    state.config = config
  }
}