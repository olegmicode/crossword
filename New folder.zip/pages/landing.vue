<template lang="pug">
  v-app(class="app")
    // header
    app-header(:config="config")
    // specific body templates
    component(:is="bodyComponents[this.config.name]" :config="config.body")
    // footer and consent
    app-footer(:config="config.navigation")
    v-footer(app)
      div
        span &copy; {{ new Date().getFullYear() }}
        span &nbsp; {{ config.navigation.contact.companyName }}
        span &nbsp; {{ $vuetify.breakpoint.name }}
    x-consent(:config="config.consent")
</template>

<script>
import pageMixin from "../mixins/xnet/pageMixin";
import HomeBody from "../components/shared/HomeBody";
import DestinationListBody from "../components/destination/DestinationListBody";
import DestinationBody from "../components/destination/DestinationBody";
import RouteListBody from "../components/route/RouteListBody";
import RouteBody from "../components/route/RouteBody";
import VehicleListBody from "../components/vehicle/VehicleListBody";
import BlogListBody from "../components/blog/BlogListBody";
import BlogBody from "../components/blog/BlogBody";
import AboutUsBody from "../components/company/AboutUsBody";
import ContactBody from "../components/company/ContactBody";
import TermsBody from "../components/company/TermsBody";
import BookingBody from "../components/sales/BookingBody";
import { mapState } from 'vuex';

export default {
  mixins: [pageMixin],
  computed: {
    ...mapState('config', ['config'])
  },
  data() {
    return {
      bodyComponents: {
        home: HomeBody,
        destinations: DestinationListBody,
        destination: DestinationBody,
        routes: RouteListBody,
        route: RouteBody,
        vehicles: VehicleListBody,
        blogs: BlogListBody,
        blog: BlogBody,
        aboutUs: AboutUsBody,
        contact: ContactBody,
        terms: TermsBody,
        booking: BookingBody
      }
    }
  },
}

</script>
