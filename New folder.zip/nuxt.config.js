import colors from 'vuetify/es5/util/colors'

export default {

  // Disable server-side rendering (https://go.nuxtjs.dev/ssr-mode)
  ssr: true,

  // Global page headers: https://go.nuxtjs.dev/config-head
  head: {
    htmlAttrs: {
      lang: 'en'
    },
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
    ],
  },

  // Global CSS: https://go.nuxtjs.dev/config-css
  css: [
  ],

  // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
  plugins: [
    { src: '~/plugins/xnet/helpers.js' },
    { src: '~/plugins/xnet/source.js' },
    { src: '~/plugins/xnet/analytics.js', mode: 'client' },
    { src: '~/plugins/xnet/cookies.js' },
    { src: "~/plugins/bmr/global.js" },
    { src: '~/plugins/bmr/source.js' },
    { src: "~/plugins/bmr/maps.js" },
  ],

  // Auto import components: https://go.nuxtjs.dev/config-components
  components: [
    '~/components',
    '~/components/shared',
    '~/components/company',
    '~/components/sales',
    '~/components/xnet/shared',
    '~/components/xnet/page',
    '~/components/xnet/menu',
    '~/components/xnet/form',
  ],

  // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
  buildModules: [
    // https://go.nuxtjs.dev/vuetify
    '@nuxtjs/vuetify',
    '@nuxtjs/router'
  ],

  // Modules: https://go.nuxtjs.dev/config-modules
  modules: [
    '@nuxtjs/axios',
    'nuxt-webfontloader',
    'nuxt-helmet',
  ],

  webfontloader: {
    google: {
      families: ['Roboto:100,300,400,500,700,900&display=swap']
    }
  },

  // Vuetify module configuration: https://go.nuxtjs.dev/config-vuetify
  vuetify: {
    theme: {
      dark: false,
      themes: {
        light: {
          primary: '#30a52e',
          secondary: '#b4332f',
          backdrop: '#f5f5f5',
          schubert: '#333',
          accent: colors.grey.darken3,
        },
        dark: {
          primary: '#30a52e',
          secondary: '#b4332f',
          backdrop: '#1e1e1e',
          schubert: '#333',
          accent: colors.grey.darken3,
          info: colors.teal.lighten1,
          warning: colors.amber.base,
          error: colors.deepOrange.accent4,
          success: colors.green.accent3
        }
      }
    },
    defaultAssets: {
      icons: 'mdiSvg',
      font: false
    }
  },

  // helmet options
  // @see https://helmetjs.github.io/docs/
  helmet: {
    noSniff: true,
    frameguard: {
      action: "sameorigin",
    }
  },

  // Build Configuration: https://go.nuxtjs.dev/config-build
  build: {
    extractCSS: true,
    transpile: [/^vue2-google-maps($|\/)/],
    babel: {
      plugins: [
          ['@babel/plugin-proposal-private-methods', { loose: true }],
          ["@babel/plugin-proposal-private-property-in-object", { loose: true }]
      ],
    },
  },

  router: {
    middleware: 'config'
  },

  // env variables
  publicRuntimeConfig: {
    appURL: process.env.APP_URL,
    apiURL: process.env.APP_API,
    schemaURL: process.env.SCHEMA_API,
    bmrURL: process.env.BMR_API,
    googleApiKey: process.env.GOOGLE_API_KEY,
    googleAnalyticsId: process.env.GOOGLE_ANALYTICS_ID,
    googleAnalyticsEnabled: process.env.GOOGLE_ANALYTICS_ENABLED,
    gdprAcceptEnabled: process.env.GDPR_ACCEPT_ENABLED,
    cookieExpiryDays: process.env.COOKIE_EXPIRY_DAYS
  },
  privateRuntimeConfig: {
  },

}
