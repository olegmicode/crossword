
export default {

    data() {
        return {
            query: null,
            loading: false
        }
    },

    methods: {

        setAllSources (config) {

            // no apis to set
            if (!config) return

            // loop through all
            const self = this
            let service = null
            Object.keys(config).forEach(key => {
                service = self.getSourceService(key)
                if (service)
                    service.setToken(config[key])
            })
        },
        getFromSource(config, query, force = false) {

            // define query
            if (!query) query = {}
            if (config.query)
                Object.assign(query, this.getContextQuery(config.query))

            // avoid redundant load
            if (!force && this.isQueryEqual(query))
                return

            // get service
            const service = this.getSourceService(config.api)
            if (!service) return

            // get data
            service.get(config.route, query)
                .then(response => {
                    this.query = query
                    this.loading = false
                    this.setFromSource(response)
                }, reason => {
                    this.loading = false
                    console.log(reason)
                })
        },
        setFromSource(data) {
        },
        getSourceService(key) {
            key = '$' + (key ?? 'api')
            return this[key]
        },
        getContextQuery(query) {

            const result = {}

            // arguments not valid
            if (!Array.isArray(query))
                return result

            // get context query
            let context = this.$nuxt.context.query
            if (!context || !this.$isObjectEmpty(context))
                return result

            // copy available params
            query.forEach((key) => {
                if (context[key])
                    result[key] = context[key]
            })

            return result
        },
        isQueryEqual(query) {

            // both empty
            if (!query && !this.query)
                return true

            // one is empty
            if (!this.query || !query)
                return false

            // compare every key
            return Object.keys(this.query).every(key =>
                query[key] === this.query[key])
        },
    }
};
