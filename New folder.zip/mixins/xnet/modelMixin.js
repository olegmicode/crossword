
export default {
    props: {
        form: {
            type: Object,
            required: true
        },
        model: {
            type: Object,
            required: true
        },
    },

    data() {
        return {}
    },

    mounted() {},

    computed: {

        inherit() {
            return {
                model:this.model,
                form:this.form
            }
        },
    },

    methods: {

        setConditionWatcher() {
            this.$watch(
                () => this.form.version,
                () => {
                    this.setCondition()
                })
        },
        evalCondition(condition) {
            condition = condition.replace('model', 'this.model')
            return eval(condition)
        },
    }
};
