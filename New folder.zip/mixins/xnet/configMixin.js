
export default {

    props: {
        config: {
            type: Object,
            required: true
        },
        translations: {
            type: Object,
            required: false
        },
    },

    data() {
        return {
            condition: true
        }
    },

    computed: {
        inherit() {
            return {}
        },
        isCondition() {
            return this.checkCondition()
        },
    },

    mounted() {
        this.setCondition()
        this.setConditionWatcher()
    },

    methods: {

        setConditionWatcher() {
        },
        setCondition() {
            this.condition = this.checkCondition()
        },
        checkCondition() {

            // no condition
            if (!this.config.condition)
                return true

            // string condition
            if (!Array.isArray(this.config.condition))
                return this.evalCondition(this.config.condition)

            // array of conditions
            return this.config.condition.every(
                (condition) => { return this.evalCondition(condition) }
            )
        },
        evalCondition(condition) {
            return true
        },
        trans(key, replace) {

            // get translation by key
            let result = this.getTranslation(key)
            if (!result) return ''

            // nothing to replace
            if (!replace) return result

            // replace placeholders
            Object.keys(replace).forEach(
                key => result = result.replace(':' + key, replace[key])
            )

            return result
        },
        getTranslation(key) {
            if (this.translations)
                return this.translations[key]
            if (this.config.translations[key])
                return this.config.translations[key]
            return null
        }
    }
}
