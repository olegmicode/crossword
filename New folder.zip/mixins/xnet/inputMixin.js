import configMixin from "./configMixin";
import optionsMixin from "./optionsMixin";
import modelMixin from "./modelMixin";
import eventBus from "../../components/xnet/services/bus.js"

export default {
  mixins: [configMixin, modelMixin, optionsMixin],

  data() {
    return {
      default: null,
      value: null,
      clean: null,
      source: 'default',
      version: 0,
      layout: {},
      errors: [],
    }
  },

  created() {
    // default
    this.setDefaultValue()
  },

  mounted() {

    // watch top-down changes
    this.setFormWatcher()

  },

  computed: {
    dirty() {
      return this.value !== this.clean
    },
    validate() {
      // no validations
      if (this.$isObjectEmpty(this.config.validations))
        return false

      // if submitted, validate
      if (this.form.submitted)
        return true

      // if feedback dirty and form is dirty
      return this.form.feedback === 'dirty'
          && this.form.dirty
    },
    rules() {
      return this.validate ? this.getValidationRules() : []
    },
    validations() {
      return this.errors
    },
    invalid() {
      return this.validate && !this.$isObjectEmpty(this.errors)
    },
  },

  methods: {

    setFormWatcher() {

      this.$watch(
          () => this.form.version,
          (newVal) => {

            // change from form level
            if (this.form.source[this.config.model] === 'source')
              this.changedModelValue('source')

            // update local version
            this.version = newVal

            // check conditions
            this.setDependencies()
          })
    },

    setDefaultValue() {
      if (this.default === null)
        return
      this.value = this.default
      this.clean = this.default
      this.changedLocalValue()
    },
    onInputChange() {
      this.changedLocalValue()
    },
    changedModelValue() {
      this.setLocalValue()
      this.source = this.form.source[this.config.model]
      this.clean = this.value
      // this.setValidations()
    },
    changedLocalValue(source = 'input') {
      this.setModelValue()
      this.form.source[this.config.model] = source
      this.form.version++
      this.form.last = this.config.model
      this.form.dirty = this.dirty
      this.emitChangedEvent()
      // this.setValidations()
    },
    emitChangedEvent() {
      let payload = {
        form: this.form.ref,
        name: this.config.name,
        value: this.value,
      }
      eventBus.$emit('input-changed', payload)
    },
    setLocalValue() {
      this.value = this.model[this.config.model]
    },
    setModelValue(source) {
      this.model[this.config.model] = this.value
    },

    setDependencies() {
    },
    getValidationRules() {
      return Object.keys(this.config.validations).map((key) => {
        return this.$callFunction(this, 'getValidation' + this.$upperCaseFirst(key))
      })
    },
    getValidationRequired() {
      return v => !this.config.validations.required
          || !!v
          || this.config.messages['validation.required']
    },
  }
};
