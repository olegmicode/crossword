import SourceMixin from "./sourceMixin";

export default {

    mixins: [ SourceMixin ],

    head() {
        return this.getHeadConfig()
    },
    mounted() {
        this.setLocalization()
    },
    created() {
        if (!this.config)
            return
        this.setAllSources(this.config.token)
    },
    methods: {

        setLocalization() {
            this.$vuetify.lang.current = this.getLanguage()
        },
        getLanguage() {
            const def = 'en'
            if (!this.config.head)
                return def

            return this.config.head.language ?? def
        },
        getHeadConfig() {

            // lang
            const result = {
                htmlAttrs: {
                    lang: this.getLanguage()
                },
            }

            // if head not defined, abort
            const config = this.config.head
            if (!config) return null

            // add meta tags
            result.title = config.title ?? '(untitled)'
            result.meta = this.getHeadMeta(config)
            result.link = this.getHeadLinks(config)

            return result
        },

        getHeadMeta(config) {

            const result = []
            let get = null

            // SEO meta description
            if ((get = this.getHeadMetaDescription(config)))
                result.push(get)

            // no index for non SEO pages
            if ((get = this.getHeadMetaNoIndex(config)))
                result.push(get)

            return result
        },
        getHeadMetaDescription(config) {

            if (!config.metaDescription)
                return null

            return {
                hid: 'description',
                name: 'description',
                content: config.metaDescription
            };
        },
        getHeadMetaNoIndex(config) {

            if (config.indexing)
                return null

            return {
                hid: 'robots',
                name: 'robots',
                content: 'noindex'
            }
        },

        getHeadLinks(config) {

            const result = []
            let get = null

            // favicon link
            if ((get = this.getLinkFavicon(config)))
                result.push(get)

            // alternate languages
            if ((get = this.getLinkAlternates(config)))
                result.push(...get)

            return result
        },
        getLinkFavicon(config) {

            return {
                rel: 'icon',
                type: 'image/x-icon',
                href: config.favicon ?? '/favicon.ico'
            }
        },
        getLinkAlternates(config) {

            if (!config.alternatives)
                return null

            // alternatives
            const result = []
            for (const [ key, item ] of Object.entries(config.alternatives))
                result.push(this.getLinkAlternate(key, item))

            return result
        },
        getLinkAlternate(language, route) {

            if (!route.startsWith('http')
                && this.$config.appURL)
                route = this.$config.appURL + route

            return {
                rel: 'alternate',
                hreflang: language === 'default' ? 'x-default' : language,
                href: route
             }
        },
    }
};
