import configMixin from "./configMixin";
import sourceMixin from "./sourceMixin";
import eventBus from "../../components/xnet/services/bus.js"

export default {
  mixins: [configMixin, sourceMixin],

  data: function () {
    return {
      model: {},
      form: {
        ref: this.config.name + '-form',
        version: 0,
        dirty: false,
        submitted: false,
        submitting: false,
        source: [],
        errors: {},
        editable: this.config.editable,
        feedback: this.config.feedback
      },
      inputOptions: {},
      warning: null,
    }
  },

  computed: {

    invalid() {
      return this.form.submitted
          && this.form.errors
          && !this.$isObjectEmpty(this.form.errors)
    },

    // inherit properties to fields
    fieldInherit() {
      return {
        form: this.form,
        model: this.model,
        inheritOptions: this.inputOptions
      }
    },
  },

  created: function () {

    // listen to local input changes
    this.setInputChangeListener()

    // set the model values from data source
    this.getFromSource(this.config.source)
  },

  methods: {

    // check condition of specific field
    isFieldCondition(name) {
      if (!this.config.fields[name])
        return false
      if (!this.config.fields[name].condition)
        return true

      let condition = this.config.fields[name].condition.replace('model', 'this.model')
      return eval(condition)
    },

    // set the model values from data source
    setFromSource(data) {

      if (!data || !data.model) return
      this.model = Object.assign({}, this.model, data.model)
      // Object.assign(this.model, data.model)
      Object.keys(data.model).forEach((key) => {
        this.form.source[key] = 'source'
      })
      this.form.version++
    },

    // generic click handler, calls function as per button function
    handleClick(funct, payload) {
      this.$callFunction(this, 'handle' + this.$upperCaseFirst(funct), payload)
    },

    // handle submit action
    handleSubmit(payload) {

      // validate
      this.form.submitted = true
      if (!this.$refs[this.form.ref].validate())
        return this.setWarning(this.config.messages['validation.errors'])

      // set service
      const service = this.getSourceService(this.config.source.api)
      if (!service) return

      // get submit promise
      const submit = this.runSubmit(service)
      if (!submit) return

      this.setWarning()
      this.form.submitting = true
      submit.then(() => this.form.submitting = false)
    },
    resolveSubmit(response) {
      // todo: defined default
    },
    rejectSubmit(reason) {
      console.log(reason)
      // todo: defined default
    },
    setWarning(warning) {
      this.warning = warning ?? null
    },
    async runSubmit(service) {
      // todo: define default
      return service.get('test')
          .then(response => {
            this.resolveSubmit(response)
          }, reason => {
            this.rejectSubmit(reason)
          })
    },

    // listen to input changes
    setInputChangeListener() {
      eventBus.$on('input-changed', (payload) => {
        if (payload && payload.form === this.form.ref)
          this.handleChangedInput(payload)
      })
    },
    // handle to input changes
    handleChangedInput(payload) {
    }
  }
};
