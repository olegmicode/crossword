export default {

    methods: {

        getMarkUpParagraphs(content) {

            if (!content) return []

            return content.split(/\r?\n/).map(text => this.getMarkUpParagraph(text))
        },
        getMarkUpParagraph(text) {

            const result = { text }
            const firstSpace = text.indexOf(' ')
            if (firstSpace < 0) return result

            result.style = this.getMarkUpStyle(text.substr(0, firstSpace))
            if (result.style)
                result.text = text.substr(firstSpace + 1)

            return result
        },
        getMarkUpStyle(prefix) {

            switch (prefix) {
                case '#':
                    return 'subHeading'
                default:
                    return null
            }
        }
    }
};
