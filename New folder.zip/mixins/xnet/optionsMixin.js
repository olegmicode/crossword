export default {
    props: {
        inheritOptions: {
            type: Object,
            required: false,
            default: () => ({})
        },
    },

    data() {
        return {
            options: {},
            elements: ['root'],
        }
    },

    created() {
        this.setOptions()
    },

    methods: {
        setOptions() {
            this.elements.forEach(element => this.setElementOptions(element))
        },
        setElementOptions(element) {
            // no defined
            if (!this.options[element])
                this.options[element] = {};
            // general options
            if (this.inheritOptions.all)
                this.$assignToObject(this.options[element], this.inheritOptions.all)
            // element options
            if (this.inheritOptions[element])
                this.$assignToObject(this.options[element], this.inheritOptions[element])
        },
        bindOptions(element) {
            if (!element) element = this.elements[0]
            return this.options[element]
        },
    }
};
