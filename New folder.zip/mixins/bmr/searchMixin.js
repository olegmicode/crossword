import formMixin from "../xnet/formMixin";

export default {

  mixins: [formMixin],

  data: function () {
    return {
      travelDays: this.config.settings.travelDays ?? 14,
      searchTips: [],
    }
  },

  methods: {

    handleChangedInput(payload) {
      if (payload.name === 'pickUpDate')
        this.checkDropOffDate(payload.value)
    },

    checkDropOffDate(pickUpDate) {

      // model not defined
      if (!this.model) return false

      // get dates
      pickUpDate = this.$parseToDate(pickUpDate)
      let dropOffDate = this.$parseToDate(this.model.dropOffDate)

      // not applicable
      if (!(pickUpDate instanceof Date))
        return false;

      // no drop-off
      if (!(dropOffDate instanceof Date))
        return this.setDropOffDate(pickUpDate)

      // diff days check
      const dropOffMin = new Date(Number(dropOffDate));
      dropOffMin.setDate(dropOffMin.getDate() + 5);
      const dropOffMax = new Date(Number(dropOffDate));
      dropOffMax.setDate(dropOffMax.getDate() + 30);

      // date out of range
      if (dropOffDate > dropOffMax || dropOffDate < dropOffMin)
        return this.setDropOffDate(pickUpDate)

      return true
    },
    setDropOffDate(pickUpDate) {

      // add days
      const dropOffDate = new Date(Number(pickUpDate));
      dropOffDate.setDate(dropOffDate.getDate() + this.travelDays);

      // model not defined
      if (!this.model.dropOffDate)
        this.model.dropOffDate = {}

      // set new model value
      this.model.dropOffDate.date = this.$getIsoDate(dropOffDate)
      this.form.version++
    },

    setWarning(warning, tips) {
      this.warning = warning ?? null
      this.searchTips = tips ?? []
    },
    async runSubmit(service) {

      let query = this.getSearchQuery()

      // quotes promise
      return service.get('quotes', query)
          .then(response => {
            this.resolveSubmit(response)
          }, reason => {
            this.rejectSubmit(reason)
          })
    },
    resolveSubmit(response) {
      if (response.reason)
        return this.setWarning(response.reason.text, response.tips)

      let query = response.search.queryString
      query += '&locale=' + this.config.settings.locale
      query += '&cache=' + response.cache
      this.redirectQuotes(query)
    },

    getSearchQuery() {

      let result = {
        check: true,
        agency: this.config.settings.agency,
        category: this.config.settings.category,
        locale: this.config.settings.locale
      }
      let date = null
      if ((date = this.$parseToDate(this.model.pickUpDate)))
        result.pickUpDate = this.$getIsoDate(date)
      if ((date = this.$parseToDate(this.model.dropOffDate)))
        result.dropOffDate = this.$getIsoDate(date)
      if (this.model.pickUpCity)
        result.pickUpCity = this.model.pickUpCity.slug
      if (this.model.oneWay && this.model.dropOffCity)
        result.dropOffCity = this.model.dropOffCity.slug
      if (this.model.passengers)
        result.passengers = this.model.passengers
      if (this.model.driverAge)
        result.driverAge = this.model.driverAge

      return result
    },
  }
};
