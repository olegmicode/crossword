import Vue from 'vue'
import Router from 'vue-router'

import landing from "./pages/landing";

Vue.use(Router)

export function createRouter() {
    return new Router({
        mode: 'history',
        routes: [
            {
                path: '/',
                alias: ['/:level1', '/:level1/:level2', '/:level1/:level2/:level3', '/:level1/:level2/:level3/:level4'],
                component: landing
            }
        ]
    })
}