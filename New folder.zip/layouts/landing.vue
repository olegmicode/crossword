<template lang="pug">

  v-app(class="app")
    v-app-bar(absolute prominent shrink-on-scroll fade-img-on-scroll :src="config.branding.logo")
      template(v-slot:img="{ props }")
        v-img(v-bind="props" gradient="to top right, rgba(19,84,122,.5), rgba(128,208,199,.8)")
      v-container
        v-avatar(height="100" :tile="true")
          v-img(:src="config.branding.logo")
        v-toolbar-title Call us on 12334343
        v-app-bar-nav-icon
    v-main
      nuxt
    v-main
    v-footer(app)
      span &copy; {{ new Date().getFullYear() }}

</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<style>
.app{
	font-family: "Open Sans","Helvetica Neue",Helvetica,Arial,sans-serif;
}
.app h1, .app h2, .app h3 {
	font-weight: 300;
}
</style>