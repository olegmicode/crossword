import barGraphState from './state'
import barGraphActions from './actions'
import barGraphMutations from './mutations'

export default {
  barGraphState,
  barGraphActions,
  barGraphMutations
}
