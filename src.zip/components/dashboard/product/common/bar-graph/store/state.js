export default () => ({
  items: [],
  unit: '',
  isLoading: false
})