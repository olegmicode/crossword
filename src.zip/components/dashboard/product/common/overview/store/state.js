export default () => ({
  overview: {},
  isLoading: false
})