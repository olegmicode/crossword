import overviewState from './state'
import overviewActions from './actions'
import overviewMutations from './mutations'

export default {
  overviewState,
  overviewActions,
  overviewMutations
}
