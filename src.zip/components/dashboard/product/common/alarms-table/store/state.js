export default () => ({
  loadingAlarmsTable: false,
  alarmTypes: [],
  alarms: []
})