import alarmsTableState from './state'
import alarmsTableActions from './actions'
import alarmsTableMutations from './mutations'

export default {
  alarmsTableState,
  alarmsTableActions,
  alarmsTableMutations
}
