import areaGraphState from './state'
import areaGraphActions from './actions'
import areaGraphMutations from './mutations'

export default {
  areaGraphState,
  areaGraphActions,
  areaGraphMutations
}
