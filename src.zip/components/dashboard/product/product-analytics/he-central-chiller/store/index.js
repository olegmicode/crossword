import api from '../services/api'

const module = {
  namespaced: true,
  state: {
  },

  actions: {
  },

  mutations: {
  }
}

export default module