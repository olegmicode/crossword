export default [
  'Equals',
  'Does not equal',
  'Is greater than',
  'Is greater than or equal to',
  'Is less than',
  'Is less than or equal to',
  'Is in',
  'Is not in'
]