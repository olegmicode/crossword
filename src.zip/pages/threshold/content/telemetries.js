export default [
  'Power Loss',
  'Out of Material',
  'Hopper Unstable',
  'Hopper Overfeed',
  'Hopper Over Max',
  'Max Empty Weight',
  'Mixer Failure',
  'Unable to make rate',
  'Pump Starter Fault'
]