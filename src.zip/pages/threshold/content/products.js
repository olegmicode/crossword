export default [
  'BD Batch Blender',
  'Accumeter Ovation Continuous',
  'GH Gravimetric Extrusion Control',
  'GH-F Gravimetric Additive',
  'VTC Plus Conveying',
  'NGX',
  'NGX Nomad',
  'Truetemp',
  'GP & HE Central',
  'T50 Central'
]