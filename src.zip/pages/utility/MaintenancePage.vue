<template>
  <div>
    <v-img
      class="mb-5"
      max-height="400"
      contain
      src="/images/illustrations/maintenance-illustration.svg"
    ></v-img>

    <h1 class="text-h3 font-weight-bold">{{ $t('utility.maintenance') }}</h1>
    <h2 class="title mt-4">We will be back soon</h2>
  </div>
</template>
