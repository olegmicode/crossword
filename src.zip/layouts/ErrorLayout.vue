<template>
  <div class="pa-2 pa-md-4 flex-grow-1 align-center justify-center d-flex flex-column">
    <slot></slot>
  </div>
</template>
