=== CTL Ultimate Sudoku ===
Tags: board game, brain game, crossword, grid, html5 board game, html5 sudoku, math game, numbers, sudoku
Requires at least: 4.3
Tested up to: 4.3

Add Ultimate Sudoku to CTL Arcade plugin

== Description ==
Add Ultimate Sudoku to CTL Arcade plugin